TEMA: Instrumental delgado no es riesgo cero
ESTADO: LISTA_PARA_REVISIÓN_HUMANA

COPY_FACEBOOK:
Un endoscopio más delgado puede ayudar a pasar con menos trauma. No convierte el procedimiento en algo inocuo.

Existe instrumental de calibre reducido y fibras finas. Pueden ser útiles en una vía urinaria pequeña. También puede haber lesión, fiebre o una estrechez después.

Una serie publicada no es una garantía para la siguiente persona. Menos calibre no es cero complicaciones.

La información es educativa y no sustituye una valoración médica. Cada caso debe revisarse individualmente.

UROCLINIC DR. JOVANI
Dr. Esteban Jovani Torres Guevara · Urólogo
Hospital Grinker
Av. Allende 139 Oriente · Piso Urgencias · Consultorio 1
Torreón, Coahuila
WhatsApp 871 385 2579

Número de publicidad COFEPRIS: 2408022002A00104

COPY_INSTAGRAM:
Más delgado no es riesgo cero.

Un instrumento de menor calibre puede cuidar mejor la vía urinaria. No anula infección, lesión ni una estrechez posterior. Una serie no es una garantía.

La información es educativa y no sustituye una valoración médica. Cada caso debe revisarse individualmente.

UROCLINIC DR. JOVANI
Dr. Esteban Jovani Torres Guevara · Urólogo
Hospital Grinker
Av. Allende 139 Oriente · Piso Urgencias · Consultorio 1
Torreón, Coahuila
WhatsApp 871 385 2579

Número de publicidad COFEPRIS: 2408022002A00104

URL_DESTINO:
URL_PENDIENTE_DE_VERIFICACIÓN
PUBLISHED:
false

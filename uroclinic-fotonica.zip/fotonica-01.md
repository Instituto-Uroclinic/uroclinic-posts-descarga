TEMA: La precisión es un orden, no un eslogan
ESTADO: LISTA_PARA_REVISIÓN_HUMANA

COPY_FACEBOOK:
La precisión no es un adjetivo para el anuncio. Es el orden de la decisión.

Síntomas, medición, estudios cuando están indicados y, solo entonces, una herramienta. Un láser no sustituye ese orden.

Cuando un adolescente pasa a la atención de adulto, el objetivo es cuidar la función: cómo vacía, cómo se contiene y cómo queda la anatomía. Cuidar no significa prometer que todo queda igual.

No hay un procedimiento que sirva para todos.

La información es educativa y no sustituye una valoración médica. Cada caso debe revisarse individualmente.

UROCLINIC DR. JOVANI
Dr. Esteban Jovani Torres Guevara · Urólogo
Hospital Grinker
Av. Allende 139 Oriente · Piso Urgencias · Consultorio 1
Torreón, Coahuila
WhatsApp 871 385 2579

Número de publicidad COFEPRIS: 2408022002A00104

COPY_INSTAGRAM:
Precisión no es un eslogan.

Primero se entiende el caso. El láser, si llega a usarse, viene después. No promete que la función quede igual.

Información para familias. No es un diagnóstico.

La información es educativa y no sustituye una valoración médica. Cada caso debe revisarse individualmente.

UROCLINIC DR. JOVANI
Dr. Esteban Jovani Torres Guevara · Urólogo
Hospital Grinker
Av. Allende 139 Oriente · Piso Urgencias · Consultorio 1
Torreón, Coahuila
WhatsApp 871 385 2579

Número de publicidad COFEPRIS: 2408022002A00104

URL_DESTINO:
URL_PENDIENTE_DE_VERIFICACIÓN
PUBLISHED:
false

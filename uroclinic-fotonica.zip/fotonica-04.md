TEMA: Holmium y thulium no son intercambiables
ESTADO: LISTA_PARA_REVISIÓN_HUMANA

COPY_FACEBOOK:
No todos los láseres se comportan igual en el tejido.

El Holmium:YAG trabaja cerca de los 2100 nm. El thulium de fibra, cerca de los 1940 nm. Los dos se absorben en el agua y se usan en endourología. Eso no los vuelve intercambiables.

Sirven, según el caso, para fragmentar un cálculo o para cortar un tejido. La elección depende de la anatomía, del hallazgo y de lo que se busca cuidar.

No incluimos la tabla de milímetros de la presentación original. Esos números no traían autor, año verificable ni DOI, y un milímetro de diferencia no es una promesa clínica.

Ninguna energía elimina el riesgo de sangrado, infección o cicatriz.

La información es educativa y no sustituye una valoración médica. Cada caso debe revisarse individualmente.

UROCLINIC DR. JOVANI
Dr. Esteban Jovani Torres Guevara · Urólogo
Hospital Grinker
Av. Allende 139 Oriente · Piso Urgencias · Consultorio 1
Torreón, Coahuila
WhatsApp 871 385 2579

Número de publicidad COFEPRIS: 2408022002A00104

COPY_INSTAGRAM:
No todos los láseres cortan igual.

Holmium:YAG, cerca de 2100 nm. Thulium de fibra, cerca de 1940 nm. No son la misma herramienta ni anulan el riesgo.

La tabla de milímetros de la lámina no se publica: no traía cita identificable.

La información es educativa y no sustituye una valoración médica. Cada caso debe revisarse individualmente.

UROCLINIC DR. JOVANI
Dr. Esteban Jovani Torres Guevara · Urólogo
Hospital Grinker
Av. Allende 139 Oriente · Piso Urgencias · Consultorio 1
Torreón, Coahuila
WhatsApp 871 385 2579

Número de publicidad COFEPRIS: 2408022002A00104

URL_DESTINO:
URL_PENDIENTE_DE_VERIFICACIÓN
PUBLISHED:
false
